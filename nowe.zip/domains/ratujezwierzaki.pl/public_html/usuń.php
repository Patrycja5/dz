<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: logowanie.html");
    exit();
}
$host = "localhost";
$db_user = "ytsilpwxpv_ziomek";         
$db_pass = "123Biedr@456";       
$db_name = "ytsilpwxpv_zwado";

$conn = new mysqli($host, $db_user, $db_pass, $db_name);
if ($conn->connect_error) {
    die("Błąd połączenia: " . $conn->connect_error);
}

$id = $_GET['id'] ?? null;
if (!$id || !is_numeric($id)) {
    die("Nieprawidłowe ID ogłoszenia.");
}

// Sprawdź, czy ogłoszenie należy do użytkownika
$stmt = $conn->prepare("SELECT * FROM ogloszenia WHERE id = ? AND user_id = (SELECT id FROM users WHERE username = ?)");
$stmt->bind_param("is", $id, $_SESSION['username']);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Nie masz dostępu do tego ogłoszenia.");
}

// Usuń ogłoszenie
$delete = $conn->prepare("DELETE FROM ogloszenia WHERE id = ?");
$delete->bind_param("i", $id);
if ($delete->execute()) {
    header("Location: mojeogloszenia.php?status=usunieto");
    exit();
} else {
    echo "Błąd przy usuwaniu: " . $delete->error;
}
?>
