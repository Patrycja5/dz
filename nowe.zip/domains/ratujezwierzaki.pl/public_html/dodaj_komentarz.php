<?php
// dodaj_komentarz.php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

// 0) Upewnij się, że użytkownik jest zalogowany
if (!isset($_SESSION['username'])) {
    header("Location: logowanie.html");
    exit();
}

// 1) Połączenie z bazą danych
$host     = "localhost";
$db_user  = "ytsilpwxpv_ziomek";
$db_pass  = "123Biedr@456";
$db_name  = "ytsilpwxpv_zwado";

$conn = new mysqli($host, $db_user, $db_pass, $db_name);
if ($conn->connect_error) {
    die("Błąd połączenia z bazą danych: " . $conn->connect_error);
}

// 2) Pobierz ID ogłoszenia i treść komentarza z POST
$zaginiecie_id = intval($_POST['zaginiecie_id'] ?? 0);
$tresc         = trim($_POST['tresc'] ?? '');

if ($zaginiecie_id <= 0 || $tresc === '') {
    // Ustaw informację o błędzie i wróć do strony wyświetlającej to ogłoszenie
    $_SESSION['comment_error'] = "Komentarz nie może być pusty.";
    header("Location: komentarz.php?id=" . $zaginiecie_id);
    exit();
}

// 3) Wstaw komentarz do bazy
$username = $_SESSION['username'];
$stmt = $conn->prepare("
    INSERT INTO komentarze (zaginiecie_id, username, tresc, data_dodania)
    VALUES (?, ?, ?, NOW())
");
$stmt->bind_param("iss", $zaginiecie_id, $username, $tresc);

if ($stmt->execute()) {
    // Sukces → wróć do komentarz.php? W tej lokalizacji już wczytasz komentarze
    header("Location: komentarz.php?id=" . $zaginiecie_id);
    exit();
} else {
    // Błąd SQL → przekieruj z wiadomością w sesji
    $_SESSION['comment_error'] = "Błąd podczas dodawania komentarza: " . $stmt->error;
    header("Location: komentarz.php?id=" . $zaginiecie_id);
    exit();
}

$stmt->close();
$conn->close();
?>
