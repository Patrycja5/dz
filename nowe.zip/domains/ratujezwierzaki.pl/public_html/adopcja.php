<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: logowanie.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Adopcja zwierząt</title>
  <link rel="stylesheet" href="szata.css"/>
  <style>
body {
  margin: 0;
  font-family: 'Segoe UI', sans-serif;
  background-color: #fff4dc;
  color: #333;
  padding: 20px;
}


form {
  background-color: #fff6e0;
  padding: 20px;
  border-radius: 16px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
  max-width: 600px;
  margin: 30px auto;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

form input,
form textarea {
  padding: 10px 12px;
  border: 1px solid #ccc;
  border-radius: 12px;
  font-size: 1rem;
}

form button {
  background-color: #facc15; 
  border: none;
  padding: 12px;
  border-radius: 999px;
  font-weight: bold;
  font-size: 1rem;
  cursor: pointer;
  transition: background-color 0.2s ease;
}

form button:hover {
  background-color: #fbbf24;
}


#animalsList {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 20px;
  max-width: 1200px;
  margin: 40px auto;
}


.animal-card {
  background-color: #fff;
  border-radius: 16px;
  box-shadow: 0 3px 8px rgba(0, 0, 0, 0.07);
  padding: 16px;
  text-align: center;
  transition: transform 0.2s ease;
}

.animal-card:hover {
  transform: translateY(-4px);
}

.animal-card img {
  width: 100%;
  height: 180px;
  object-fit: cover;
  border-radius: 12px;
  margin-bottom: 10px;
}

.animal-card h3 {
  margin: 10px 0 5px;
  font-size: 1.2rem;
  color: #111;
}

.animal-card p {
  font-size: 0.95rem;
  margin: 4px 0;
}


.nav-buttons {
  display: flex;
  justify-content: center;
  gap: 10px;
  margin-bottom: 20px;
}

.nav-buttons button {
  background-color: #fde68a;
  border: none;
  padding: 10px 16px;
  border-radius: 999px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
}

.nav-buttons .active {
  background-color: #f87171;
  color: white;
}

.nav-buttons button:hover {
  background-color: #fcd34d;

}
  .logo {
      width: 150px;
      height: auto;
      margin-bottom: 10px;
    }

    .tytul {
      font-size: 20px;
      text-align: center;
    }

    h1 {
      text-align: center;
      margin-top: 40px;
    }

.top-bar {
            text-align: right;
            margin-bottom: 20px;
        }
        .top-bar a {
            text-decoration: none;
            color: #fff;
            background-color: #0077cc;
            padding: 8px 16px;
            border-radius: 5px;
        }


  </style>
</head>
<body>
<div class="top-bar">
    <a href="index.php">🏠 Strona główna</a>
</div> 
    <img src="logo.png" alt="logo strony" class="logo" />
    <div class="tytul"><h1>Stwórz ogłoszenie adopcyjne </h1>
 
 <form id="addAnimalForm" method="POST" action="zapisz_ogloszenie.php" enctype="multipart/form-data">
  <input name="name" placeholder="Imię zwierzaka" required />
  <input name="species" placeholder="Gatunek" required />
  <input name="breed" placeholder="Rasa" />
  <input name="age" type="number" placeholder="Wiek" min="0" />
  <textarea name="description" placeholder="Opis zwierzaka" required></textarea>
  <input name="price" type="text" placeholder="Cena (opcjonalnie)" pattern="^\d+(\.\d{1,2})?$" />
  <input type="file" name="animal_image" accept="image/*" required />
  <button type="submit">Dodaj ogłoszenie</button>
</form>

</body>
</html>
